<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = htmlspecialchars($_POST['nome']); 
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $recado = htmlspecialchars($_POST['recado']); 

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $to = "yasmiinsantos20170@gmail.com"; 
        $subject = "Nova mensagem recebida!";
        $message = "Nome: $nome\nE-mail: $email\nRecado:\n$recado";
        $headers = "From: no-reply@seusite.com";

        if (mail($to, $subject, $message, $headers)) {
            echo "Seu email foi enviado com sucesso!";
        } else {
            echo "Erro ao enviar o email. Tente novamente.";
        }
    } else {
        echo "E-mail inválido.";
    }
}
?>
